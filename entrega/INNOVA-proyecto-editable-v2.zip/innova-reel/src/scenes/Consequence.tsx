import { interpolate, useCurrentFrame } from "remotion";
import { Stage, Reveal, RED, enter, clamp, ease } from "../design";
import { Phone, Shop } from "../Devices";
export const Consequence = () => {
  const f = useCurrentFrame();
  const morph = enter(f, 40, 20);
  const out = enter(f, 42, 12);
  return (
    <Stage glow={0.7}>
      <div
        style={{
          position: "absolute",
          top: 280,
          left: 84,
          width: 870,
          zIndex: 3,
          opacity: 1 - out,
          translate: `0 ${-out * 35}px`,
          filter: `blur(${out * 5}px)`,
        }}
      >
        <Reveal size={100} at={-2}>
          UNA CONSULTA
        </Reveal>
        <Reveal size={100} at={1}>
          SIN RESPUESTA
        </Reveal>
        <div style={{ height: 45 }} />
        <Reveal size={73} at={5}>
          PUEDE TERMINAR EN
        </Reveal>
        <Reveal size={140} color={RED} at={8}>
          OTRA COMPRA.
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: interpolate(f, [0, 14], [300, 350], { ...clamp, easing: ease }),
          top: interpolate(f, [0, 16], [500, 820], { ...clamp, easing: ease }),
          width: 470,
          height: 880,
          scale: interpolate(f, [0, 16], [1.19, 0.94], clamp),
          opacity: (1 - enter(f, 38, 8)) * 0.5,
          filter: `blur(${enter(f, 38, 10) * 4}px)`,
        }}
      >
        <Phone rotation={-4} tilt={5} dim={0.22} />
      </div>
      <div
        style={{
          position: "absolute",
          left: 160,
          top: 1050,
          display: "flex",
          gap: 14,
          padding: "25px 32px",
          borderRadius: "27px 27px 27px 5px",
          background: "#252527",
          opacity: interpolate(f, [0, 18, 28], [1, 1, 0], clamp),
        }}
      >
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            style={{
              width: 14,
              height: 14,
              borderRadius: 14,
              background: "#b4b4b9",
              translate: `0 ${Math.sin(f * 0.65 - i) * 4}px`,
            }}
          />
        ))}
      </div>
      <div
        style={{
          position: "absolute",
          left: interpolate(morph, [0, 1], [354, 120]),
          top: interpolate(morph, [0, 1], [845, 605]),
          width: interpolate(morph, [0, 1], [440, 840]),
          height: interpolate(morph, [0, 1], [820, 540]),
          opacity: enter(f, 38, 5),
          borderRadius: interpolate(morph, [0, 1], [66, 25]),
          padding: interpolate(morph, [0, 1], [13, 18]),
          background: "linear-gradient(135deg,#77777d,#151518 35%,#25252a)",
          border: "2px solid #74747a",
          overflow: "hidden",
          boxShadow: "0 35px 75px #0007",
          filter: `blur(${Math.sin(morph * Math.PI) * 2}px)`,
        }}
      >
        <div
          style={{
            height: "100%",
            borderRadius: interpolate(morph, [0, 1], [52, 6]),
            background: "#151518",
            overflow: "hidden",
            position: "relative",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              opacity: enter(f, 45, 10),
              width: 804,
              height: 498,
              transformOrigin: "top left",
              scale: interpolate(morph, [0, 1], [0.52, 1]),
            }}
          >
            <div style={{ height: 23, background: "#dadada" }} />
            <div style={{ height: 467 }}>
              <Shop preview={false} />
            </div>
          </div>
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 1142,
          width: 920,
          height: 29,
          borderRadius: "3px 3px 45px 45px",
          background: "linear-gradient(#aaaab1,#47474e 55%,#19191c)",
          scale: `${enter(f, 49, 11)} 1`,
          opacity: enter(f, 49, 8),
          boxShadow: "0 25px 45px #0008",
        }}
      />
      <div
        style={{
          position: "absolute",
          left: -600,
          top: -250,
          width: 280,
          height: 2450,
          background:
            "linear-gradient(90deg,transparent,#8e183755,#ff234b 65%,#ff234b 78%,transparent)",
          translate: `${interpolate(f, [42, 59], [0, 2150], { ...clamp, easing: ease })}px 0`,
          rotate: "-16deg",
          opacity: interpolate(f, [40, 43, 58, 60], [0, 1, 1, 0], clamp),
          filter: "blur(1px)",
          pointerEvents: "none",
        }}
      />
    </Stage>
  );
};
