import { useCurrentFrame, interpolate } from "remotion";
import { Stage, Reveal, RED, clamp, enter } from "../design";
const Chat = ({ text, at, y }: { text: string; at: number; y: number }) => {
  const f = useCurrentFrame();
  return (
    <div
      className="speech"
      style={{
        position: "absolute",
        left: 112,
        top: y,
        background: "#fafafa",
        color: "#0b0b0c",
        padding: "24px 38px",
        borderRadius: "40px 40px 40px 6px",
        fontSize: 47,
        fontWeight: 700,
        opacity: enter(f, at, 6),
        translate: `0 ${(1 - enter(f, at, 12)) * 50}px`,
        scale: interpolate(f, [at, at + 9, at + 15], [0.94, 1.015, 1], clamp),
      }}
    >
      {text}
    </div>
  );
};
export const Hook = () => (
  <Stage>
    <div style={{ position: "absolute", left: 84, top: 275, width: 890 }}>
      <Reveal at={-3} size={108}>
        ¿CUÁNTO DINERO
      </Reveal>
      <Reveal at={5} size={144}>
        PODÉS <span style={{ color: RED }}>PERDER</span>
      </Reveal>
      <Reveal at={12} size={96}>
        POR TARDAR EN
        <br />
        RESPONDER?
      </Reveal>
    </div>
    <Chat text="Hola, ¿cuánto sale?" at={16} y={980} />
    <Chat text="¿Hacés envíos?" at={31} y={1135} />
  </Stage>
);
