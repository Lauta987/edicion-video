import React from 'react';
import {AbsoluteFill,Composition,Img,Series,interpolate,spring,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
const sections=[
 {file:'1.png',frames:90,bounds:[0,210,890,1125,1330,1570,1920]},
 {file:'2.png',frames:112,bounds:[0,180,570,780,980,1180,1380,1580,1920]},
 {file:'3.png',frames:77,bounds:[0,600,1190,1450,1920]},
 {file:'4.png',frames:90,bounds:[0,280,860,1260,1450,1650,1920]},
 {file:'5.png',frames:90,bounds:[0,185,470,1340,1600,1920]},
 {file:'6.png',frames:60,bounds:[0,260,800,1080,1230,1500,1920]},
];
const Panel:React.FC<{file:string;bounds:number[]}>=({file,bounds})=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{background:'#0a0a0b',overflow:'hidden'}}>
  {bounds.slice(0,-1).map((top,i)=>{
   const height=bounds[i+1]-top;const at=i===0?0:Math.min(4+(i-1)*3,19);
   const p=spring({frame:f-at,fps,config:{damping:18,stiffness:240,mass:.7}});
   const fade=interpolate(f,[at,at+5],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
   return <div key={`${top}-${height}`} style={{position:'absolute',top,left:0,width:1080,height,overflow:'hidden',opacity:fade,translate:`${(i%2?1:-1)*(1-p)*35}px ${(1-p)*20}px`,scale:1+(1-p)*.012,transformOrigin:'center center'}}>
     <Img src={staticFile(`escenas/${file}`)} style={{position:'absolute',left:0,top:-top,width:1080,height:1920}}/>
   </div>;
  })}
 </AbsoluteFill>;
};
const Video=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><Series>
 <Series.Sequence name="01 · Consultas" durationInFrames={90} premountFor={fps}><Panel file="1.png" bounds={sections[0].bounds}/></Series.Sequence>
 <Series.Sequence name="02 · Mensajes" durationInFrames={112} premountFor={fps}><Panel file="2.png" bounds={sections[1].bounds}/></Series.Sequence>
 <Series.Sequence name="03 · Dudas" durationInFrames={77} premountFor={fps}><Panel file="3.png" bounds={sections[2].bounds}/></Series.Sequence>
 <Series.Sequence name="04 · Solución" durationInFrames={90} premountFor={fps}><Panel file="4.png" bounds={sections[3].bounds}/></Series.Sequence>
 <Series.Sequence name="05 · Web" durationInFrames={90} premountFor={fps}><Panel file="5.png" bounds={sections[4].bounds}/></Series.Sequence>
 <Series.Sequence name="06 · Cierre" durationInFrames={60} premountFor={fps}><Panel file="6.png" bounds={sections[5].bounds}/></Series.Sequence>
 </Series><Audio src={staticFile('video-original.mp4')} premountFor={fps}/></AbsoluteFill>};
export const Root=()=> <Composition id="INNOVA-Original-Animado" component={Video} width={1080} height={1920} fps={30} durationInFrames={519}/>;
