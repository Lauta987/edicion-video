import React from "react";
import {
  AbsoluteFill,
  Easing,
  interpolate,
  useCurrentFrame,
  staticFile,
  spring,
  useVideoConfig,
} from "remotion";
import { loadFont } from "@remotion/fonts";

loadFont({
  family: "Barlow",
  url: staticFile("fonts/BarlowCondensed-ExtraBold.ttf"),
  weight: "800",
});
loadFont({
  family: "Open Sans",
  url: staticFile("fonts/OpenSans-Regular.ttf"),
  weight: "400",
});
export const RED = "#ff234b";
export const BG = "#080809";
export const clamp = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;
export const ease = Easing.bezier(0.16, 1, 0.3, 1);
export const enter = (f: number, at = 0, duration = 12) =>
  interpolate(f, [at, at + duration], [0, 1], { ...clamp, easing: ease });
export const title: React.CSSProperties = {
  fontFamily: "Barlow",
  fontWeight: 800,
  lineHeight: 0.98,
  letterSpacing: -0.7,
  margin: 0,
};
export const Arrow = ({ size = 32 }: { size?: number }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 32 32"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.4"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M7 25 25 7M7 7h18v18" />
  </svg>
);

export const Stage: React.FC<{
  children: React.ReactNode;
  glow?: number;
  still?: boolean;
}> = ({ children }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: "#0a0a0b",
        color: "#f7f5f3",
        fontFamily: "Open Sans",
        overflow: "hidden",
      }}
    >
      <style>{`.speech{position:relative}.speech:after{content:"";position:absolute;left:0;bottom:-14px;width:25px;height:18px;background:inherit;clip-path:polygon(0 0,100% 0,0 100%)}`}</style>
      <div
        style={{
          position: "absolute",
          right: 55,
          top: 560,
          opacity: 0.12,
          translate: `0 ${Math.sin(f / 65) * 14}px`,
        }}
      >
        <svg
          width="165"
          height="165"
          viewBox="0 0 100 100"
          fill="none"
          stroke="#999"
          strokeWidth="1.5"
        >
          <path d="M8 16h12l10 47h51l9-35H23M35 76a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm42 0a5 5 0 1 0 0 10 5 5 0 0 0 0-10z" />
        </svg>
      </div>
      <div
        style={{
          position: "absolute",
          left: 55,
          top: 650,
          opacity: 0.13,
          translate: `0 ${Math.sin(f / 55) * 14}px`,
        }}
      >
        <svg
          width="245"
          height="220"
          viewBox="0 0 120 110"
          fill="none"
          stroke="#999"
          strokeWidth="1.4"
        >
          <path d="M10 15h80a10 10 0 0 1 10 10v45a10 10 0 0 1-10 10H35L16 94v-14h-6A10 10 0 0 1 0 70V25a10 10 0 0 1 10-10z" />
          <path d="M20 35h58M20 48h48M20 61h32" />
        </svg>
      </div>
      <div
        style={{
          position: "absolute",
          right: 45,
          top: 940,
          opacity: 0.13,
          translate: `0 ${Math.sin(f / 70 + 1) * 18}px`,
        }}
      >
        <svg
          width="200"
          height="240"
          viewBox="0 0 120 130"
          fill="none"
          stroke="#999"
          strokeWidth="1.5"
        >
          <path d="M23 42h75l10 72H13zM42 44V30a19 19 0 0 1 38 0v14" />
        </svg>
      </div>
      <div
        style={{
          position: "absolute",
          left: 84,
          top: 185,
          width: 110,
          height: 4,
          background: RED,
          scale: `${enter(f, 0, 18)} 1`,
          transformOrigin: "left",
        }}
      />
      {children}
    </AbsoluteFill>
  );
};

export const Reveal: React.FC<{
  children: React.ReactNode;
  at?: number;
  size?: number;
  color?: string;
  style?: React.CSSProperties;
}> = ({ children, at = 0, size = 100, color = "#f7f5f3", style = {} }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({
    frame: f - at,
    fps,
    config: { damping: 19, stiffness: 220, mass: 0.7 },
  });
  return (
    <div style={{ paddingBottom: 8, ...style }}>
      <div
        style={{
          ...title,
          fontSize: size,
          color,
          opacity: interpolate(f, [at - 1, at + 5], [0, 1], clamp),
          translate: `0 ${(1 - p) * 48}px`,
          scale: 1 + (1 - p) * 0.025,
          filter: `blur(${interpolate(f, [at, at + 8], [6, 0], clamp)}px)`,
        }}
      >
        {children}
      </div>
    </div>
  );
};

export const Notification: React.FC<{
  text: string;
  at: number;
  x: number;
  y: number;
  width?: number;
  small?: boolean;
}> = ({ text, at, x, y, width = 730, small = false }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({
    frame: f - at,
    fps,
    config: { damping: 13, stiffness: 230, mass: 0.65 },
  });
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width,
        opacity: enter(f, at, 5),
        translate: `${(1 - p) * 25}px ${(1 - p) * 65}px`,
        scale: 0.94 + p * 0.06,
        filter: `blur(${interpolate(f, [at, at + 7], [5, 0], clamp)}px)`,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 22,
          padding: small ? "25px 30px" : "28px 30px",
          borderRadius: "25px 25px 25px 7px",
          background: "linear-gradient(125deg,#f7f6f4,#dfdddd)",
          color: BG,
          border: "1px solid #ffffffb0",
          boxShadow: "0 22px 55px #0007, inset 0 1px 0 #fff",
          fontSize: small ? 40 : 44,
          lineHeight: 1.2,
        }}
      >
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 11,
            border: "1px solid #08080920",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
          }}
        >
          <div
            style={{ width: 7, height: 7, borderRadius: 8, background: RED }}
          />
        </div>
        <span>{text}</span>
      </div>
    </div>
  );
};

export const Icon: React.FC<{ kind?: string; size?: number }> = ({
  kind = "box",
  size = 36,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 32 32"
    fill="none"
    stroke={RED}
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {kind === "card" ? (
      <>
        <rect x="3" y="7" width="26" height="19" rx="4" />
        <path d="M3 13h26M8 21h6" />
      </>
    ) : kind === "truck" ? (
      <>
        <path d="M3 8h16v17H3zM19 14h6l4 5v6H19M4 15h9" />
        <circle cx="9" cy="25" r="3" fill={BG} />
        <circle cx="24" cy="25" r="3" fill={BG} />
      </>
    ) : kind === "chat" ? (
      <path d="M7 5h18a4 4 0 0 1 4 4v11a4 4 0 0 1-4 4H13l-8 5v-6a4 4 0 0 1-3-4V9a4 4 0 0 1 5-4zM10 12h12M10 17h8" />
    ) : (
      <>
        <path d="m16 3 12 7v13l-12 7-12-7V10zM4 10l12 7 12-7M16 17v13M10 6l12 7" />
      </>
    )}
  </svg>
);
