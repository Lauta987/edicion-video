import {
  AbsoluteFill,
  Composition,
  Folder,
  Series,
  staticFile,
  useVideoConfig,
} from "remotion";
import { Audio } from "@remotion/media";
import { Hook } from "./scenes/Hook";
import { Problem } from "./scenes/Problem";
import { Consequence } from "./scenes/Consequence";
import { Solution } from "./scenes/Solution";
import { Closing } from "./scenes/Closing";
export const InnovaReel = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill>
      <Series>
        <Series.Sequence
          name="01 · Gancho"
          durationInFrames={2.5 * fps}
          premountFor={fps}
        >
          <Hook />
        </Series.Sequence>
        <Series.Sequence
          name="02 · El problema"
          durationInFrames={3 * fps}
          premountFor={fps}
        >
          <Problem />
        </Series.Sequence>
        <Series.Sequence
          name="03 · Consecuencia"
          durationInFrames={2 * fps}
          premountFor={fps}
        >
          <Consequence />
        </Series.Sequence>
        <Series.Sequence
          name="04 · La solución"
          durationInFrames={4 * fps}
          premountFor={fps}
        >
          <Solution />
        </Series.Sequence>
        <Series.Sequence
          name="05 · INNOVA / CTA"
          durationInFrames={4.5 * fps}
          premountFor={fps}
        >
          <Closing />
        </Series.Sequence>
      </Series>
      <Audio src={staticFile("audio/innova-master.wav")} premountFor={fps} />
    </AbsoluteFill>
  );
};
export const RemotionRoot = () => (
  <>
    <Composition
      id="INNOVA-Reel"
      component={InnovaReel}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={480}
    />
    <Folder name="Escenas">
      <Composition
        id="Gancho"
        component={Hook}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={75}
      />
      <Composition
        id="Problema"
        component={Problem}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={90}
      />
      <Composition
        id="Consecuencia"
        component={Consequence}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={60}
      />
      <Composition
        id="Solucion"
        component={Solution}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={120}
      />
      <Composition
        id="Cierre"
        component={Closing}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={135}
      />
    </Folder>
  </>
);
