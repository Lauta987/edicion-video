import { useCurrentFrame, Img, staticFile, Freeze } from "remotion";
import { Stage, Reveal, RED, title, Arrow, enter } from "../design";
import { Laptop } from "../Devices";
const Inner = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <div
        style={{
          position: "absolute",
          left: 454,
          top: 215,
          width: 160,
          height: 160,
          opacity: enter(f, 0, 14),
        }}
      >
        <Img
          src={staticFile("brand/innova.png")}
          style={{ width: "100%", height: "100%", objectFit: "contain" }}
        />
      </div>
      <div
        style={{
          position: "absolute",
          left: 155,
          top: 420,
          scale: 0.82,
          transformOrigin: "top left",
          opacity: enter(f, 0, 12),
        }}
      >
        <Laptop angle={0} tilt={0} settled />
      </div>
      <div style={{ position: "absolute", left: 84, top: 990, width: 870 }}>
        <Reveal at={5} size={78}>
          TU WEB RESPONDE LO BÁSICO.
        </Reveal>
        <Reveal at={15} size={65} color={RED}>
          VOS ATENDÉS CONSULTAS REALES.
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: 84,
          top: 1240,
          fontSize: 32,
          letterSpacing: 1.8,
          opacity: enter(f, 24),
        }}
      >
        INNOVA — SOLUCIONES DIGITALES
      </div>
      <div
        className="speech"
        style={{
          position: "absolute",
          left: 84,
          top: 1360,
          width: 840,
          height: 135,
          borderRadius: "35px 35px 35px 6px",
          background: RED,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 24,
          opacity: enter(f, 30, 8),
          translate: `0 ${(1 - enter(f, 30)) * 30}px`,
        }}
      >
        <span style={{ ...title, fontSize: 48 }}>
          ESCRIBINOS ‘WEB’ POR WHATSAPP
        </span>
        <Arrow size={38} />
      </div>
    </Stage>
  );
};
export const Closing = () => {
  const f = useCurrentFrame();
  return f >= 78 ? (
    <Freeze frame={78}>
      <Inner />
    </Freeze>
  ) : (
    <Inner />
  );
};
