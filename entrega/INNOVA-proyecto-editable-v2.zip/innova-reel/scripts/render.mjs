import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { mkdirSync } from "node:fs";
const require = createRequire(import.meta.url);
const cli = join(
  dirname(require.resolve("@remotion/cli/package.json")),
  "remotion-cli.js",
);
const run = (command, args, options = {}) => {
  const r = spawnSync(command, args, { stdio: "inherit", ...options });
  if (r.error) throw r.error;
  if (r.status !== 0) process.exit(r.status ?? 1);
  return r;
};
mkdirSync("out", { recursive: true });
const intermediate = "out/INNOVA-Reel-v2-render.mp4";
const final = "out/INNOVA-Reel-v2.mp4";
run(process.execPath, [
  cli,
  "render",
  "src/index.ts",
  "INNOVA-Reel",
  intermediate,
  "--codec=h264",
  "--crf=14",
  "--pixel-format=yuv420p",
  "--audio-codec=aac",
  "--audio-bitrate=320k",
  "--concurrency=3",
  ...process.argv.slice(2),
]);
const metadata = run(
  "ffprobe",
  [
    "-v",
    "error",
    "-select_streams",
    "v:0",
    "-show_entries",
    "stream=duration",
    "-of",
    "json",
    intermediate,
  ],
  { stdio: ["ignore", "pipe", "inherit"], encoding: "utf8" },
);
const duration = JSON.parse(metadata.stdout).streams[0].duration;
// Keep the lossless video stream from Remotion's CRF 14 encode. Trim AAC padding
// to the exact video duration and place the MP4 index first for fast playback.
run("ffmpeg", [
  "-y",
  "-hide_banner",
  "-loglevel",
  "warning",
  "-i",
  intermediate,
  "-map",
  "0:v:0",
  "-map",
  "0:a:0",
  "-c:v",
  "copy",
  "-c:a",
  "aac",
  "-b:a",
  "320k",
  "-af",
  `atrim=duration=${duration}`,
  "-t",
  duration,
  "-movflags",
  "+faststart",
  final,
]);
console.log(`Final: ${final} (${duration} seconds)`);
