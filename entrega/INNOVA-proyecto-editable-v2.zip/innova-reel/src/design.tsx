import React from "react";
import {
  AbsoluteFill,
  Easing,
  interpolate,
  useCurrentFrame,
  staticFile,
  spring,
  useVideoConfig,
} from "remotion";
import { loadFont } from "@remotion/fonts";

loadFont({
  family: "Barlow",
  url: staticFile("fonts/BarlowCondensed-ExtraBold.ttf"),
  weight: "800",
});
loadFont({
  family: "Open Sans",
  url: staticFile("fonts/OpenSans-Regular.ttf"),
  weight: "400",
});
export const RED = "#ff234b";
export const BG = "#080809";
export const clamp = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;
export const ease = Easing.bezier(0.16, 1, 0.3, 1);
export const enter = (f: number, at = 0, duration = 12) =>
  interpolate(f, [at, at + duration], [0, 1], { ...clamp, easing: ease });
export const title: React.CSSProperties = {
  fontFamily: "Barlow",
  fontWeight: 800,
  lineHeight: 0.98,
  letterSpacing: -0.7,
  margin: 0,
};
export const Arrow = ({ size = 32 }: { size?: number }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 32 32"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.4"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M7 25 25 7M7 7h18v18" />
  </svg>
);

export const Stage: React.FC<{
  children: React.ReactNode;
  glow?: number;
  still?: boolean;
}> = ({ children, glow = 1, still = false }) => {
  const frame = useCurrentFrame();
  const f = still ? 78 : frame;
  return (
    <AbsoluteFill
      style={{
        background: BG,
        color: "#f7f5f3",
        fontFamily: "Open Sans",
        overflow: "hidden",
      }}
    >
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse 70% 48% at ${63 + Math.sin(f / 100) * 3}% 65%, rgba(123,15,36,${0.21 * glow}), transparent 76%), radial-gradient(ellipse at 20% 5%,#19131644,transparent 50%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 40,
          right: 40,
          top: 1450,
          height: 230,
          background: "radial-gradient(ellipse,#000a,transparent 68%)",
          filter: "blur(20px)",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: 186,
          left: 84,
          width: 142,
          height: 3,
          background: "#ffffff0b",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            height: "100%",
            background: RED,
            width: interpolate(frame, [0, 15, 30], [0, 142, 64], {
              ...clamp,
              easing: ease,
            }),
          }}
        />
      </div>
      {children}
    </AbsoluteFill>
  );
};

export const Reveal: React.FC<{
  children: React.ReactNode;
  at?: number;
  size?: number;
  color?: string;
  style?: React.CSSProperties;
}> = ({ children, at = 0, size = 100, color = "#f7f5f3", style = {} }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({
    frame: f - at,
    fps,
    config: { damping: 19, stiffness: 220, mass: 0.7 },
  });
  return (
    <div style={{ paddingBottom: 8, ...style }}>
      <div
        style={{
          ...title,
          fontSize: size,
          color,
          opacity: interpolate(f, [at - 1, at + 5], [0, 1], clamp),
          translate: `0 ${(1 - p) * 48}px`,
          scale: 1 + (1 - p) * 0.025,
          filter: `blur(${interpolate(f, [at, at + 8], [6, 0], clamp)}px)`,
        }}
      >
        {children}
      </div>
    </div>
  );
};

export const Notification: React.FC<{
  text: string;
  at: number;
  x: number;
  y: number;
  width?: number;
  small?: boolean;
}> = ({ text, at, x, y, width = 730, small = false }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({
    frame: f - at,
    fps,
    config: { damping: 13, stiffness: 230, mass: 0.65 },
  });
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width,
        opacity: enter(f, at, 5),
        translate: `${(1 - p) * 25}px ${(1 - p) * 65}px`,
        scale: 0.94 + p * 0.06,
        filter: `blur(${interpolate(f, [at, at + 7], [5, 0], clamp)}px)`,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 22,
          padding: small ? "25px 30px" : "28px 30px",
          borderRadius: "25px 25px 25px 7px",
          background: "linear-gradient(125deg,#f7f6f4,#dfdddd)",
          color: BG,
          border: "1px solid #ffffffb0",
          boxShadow: "0 22px 55px #0007, inset 0 1px 0 #fff",
          fontSize: small ? 40 : 44,
          lineHeight: 1.2,
        }}
      >
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 11,
            border: "1px solid #08080920",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
          }}
        >
          <div
            style={{ width: 7, height: 7, borderRadius: 8, background: RED }}
          />
        </div>
        <span>{text}</span>
      </div>
    </div>
  );
};

export const Icon: React.FC<{ kind?: string; size?: number }> = ({
  kind = "box",
  size = 36,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 32 32"
    fill="none"
    stroke={RED}
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {kind === "card" ? (
      <>
        <rect x="3" y="7" width="26" height="19" rx="4" />
        <path d="M3 13h26M8 21h6" />
      </>
    ) : kind === "truck" ? (
      <>
        <path d="M3 8h16v17H3zM19 14h6l4 5v6H19M4 15h9" />
        <circle cx="9" cy="25" r="3" fill={BG} />
        <circle cx="24" cy="25" r="3" fill={BG} />
      </>
    ) : kind === "chat" ? (
      <path d="M7 5h18a4 4 0 0 1 4 4v11a4 4 0 0 1-4 4H13l-8 5v-6a4 4 0 0 1-3-4V9a4 4 0 0 1 5-4zM10 12h12M10 17h8" />
    ) : (
      <>
        <path d="m16 3 12 7v13l-12 7-12-7V10zM4 10l12 7 12-7M16 17v13M10 6l12 7" />
      </>
    )}
  </svg>
);
