# INNOVA · Tu web responde lo básico

Reel de 16 segundos, 1080 × 1920, 30 FPS. Motion graphics en React/Remotion, MP4 H.264 y sonido estéreo. Sin voz en off.

## Abrir y editar

Requisitos: FFmpeg/ffprobe en PATH y Node.js 24 (también compatible con los rangos declarados en package.json) y npm.

```sh
npm ci
npm run dev -- --no-open
```

Abrir Remotion Studio y seleccionar `INNOVA-Reel`. Las cinco escenas también tienen composiciones independientes dentro de `Escenas`. Texto, posiciones, colores y tiempos se editan en los archivos TSX. Las animaciones dependen del fotograma, por lo que el render es determinista.

## Exportar

```sh
npm run render
```

En el entorno de nube, con Chromium ya instalado:

```sh
npm run render -- --browser-executable=/usr/bin/chromium
```

Salida: `out/INNOVA-Reel-v2.mp4`. Codec H.264, CRF 14, yuv420p, AAC 320 kb/s. Remotion puede descargar su navegador si no se especifica uno local. No requiere cuentas, API keys ni servicios externos.

## Organización

- `src/Root.tsx`: línea de tiempo principal y composiciones conectadas.
- `src/scenes/`: gancho 0–2,5 s, problema 2,5–5,5 s, consecuencia y transformación 5,5–7,5 s, solución 7,5–11,5 s, cierre 11,5–16 s.
- `src/Devices.tsx`: teléfono con perspectiva 3D, notebook y tienda de demostración.
- `src/design.tsx`: tipografía, color, íconos y entradas de texto.
- `public/brand/innova.png`: símbolo con transparencia preparado a partir del logo adjunto. No es un archivo vectorial maestro.
- `public/products/`: ilustraciones SVG originales de los productos.
- `public/fonts/`: Barlow Condensed ExtraBold y Open Sans Regular, con sus licencias.
- `public/audio/music-original.wav`: instrumental electrónica original, 120 BPM.
- `public/audio/sound-design.wav`: notificaciones, impactos y barridos sintetizados para la pieza.
- `public/audio/innova-master.wav`: mezcla utilizada en el reel, 48 kHz, estéreo.
- `scripts/make_audio.py`: fuente editable de la música y los efectos; requiere Python 3 y numpy para regenerarlos. No hace falta ejecutarlo para editar o renderizar el video.

Para regenerar el audio desde esta carpeta:

```sh
python3 scripts/make_audio.py
ffmpeg -y -i public/audio/pre-master.wav -af loudnorm=I=-15:TP=-1.5:LRA=7 -ar 48000 public/audio/innova-master.wav
```

La tienda NIDO, sus productos y sus precios son contenido de demostración. No son cifras de resultados ni promesas comerciales. El CTA es visual: no contiene un número ni un enlace de WhatsApp que no haya sido proporcionado.

Los titulares y el CTA están dentro del área segura (aprox. x84–924, y250–1580). Los dispositivos pueden extenderse fuera de ella. Revisar igualmente la previsualización de cada plataforma al publicar porque sus interfaces cambian.

## Verificación

```sh
npm run lint
```

Se revisaron fotogramas de las cinco escenas y se verificó la exportación con ffprobe y decodificación completa de FFmpeg. El enlace de Instagram no pudo reproducirse en el entorno por una restricción de acceso; la edición sigue el guion y la dirección visual escrita del encargo.

Usar el checkout existente en este entorno; no hace falta crear un worktree adicional. El servidor de Studio debe iniciarse de nuevo al abrir otra sesión.

## Edición v2

Se conserva el contenido de la primera pieza, incluida la frase de consecuencia, y la duración se ajusta a 16 segundos para dar espacio a su lectura. Las escenas ahora comparten poses de entrada y salida para conectar el teléfono, los mensajes y la notebook.

- Entradas de titulares con desplazamiento corto, escala, desenfoque breve y amortiguación.
- Teléfono que sube desde abajo, notificaciones con rebote y pila que desplaza los mensajes previos.
- Compresión de las consultas hacia el dispositivo y transformación de pantalla con barrido rojo diagonal.
- Notebook con asentamiento, profundidad, sombra de contacto y reflejo tenue.
- Interfaz NIDO con foco de productos, pagos, envíos y contacto; íconos con microanimaciones diferentes.
- CTA con borde y un brillo único al entrar. La composición completa se congela desde 14,1 s: 1,9 s de lectura estable.
- Instrumental original conservada y extendida a 16 s, con efectos resincronizados con los movimientos.

La exportación usa fotogramas PNG, color Rec.709, H.264 de alta calidad y audio AAC estéreo. El script `scripts/render.mjs` recorta el relleno de AAC a la duración del video, preserva el flujo de video sin recodificarlo y agrega faststart.
