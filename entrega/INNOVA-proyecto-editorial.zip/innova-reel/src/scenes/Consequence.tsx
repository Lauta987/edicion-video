import { useCurrentFrame, interpolate } from "remotion";
import { Stage, Reveal, RED, clamp } from "../design";
export const Consequence = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <div
        className="speech"
        style={{
          position: "absolute",
          left: 84,
          top: 330,
          width: 850,
          background: "#f7f7f5",
          color: "#0a0a0b",
          borderRadius: "55px 55px 55px 8px",
          padding: "55px 45px",
        }}
      >
        <Reveal size={100} color="#0a0a0b">
          UNA CONSULTA
        </Reveal>
        <Reveal at={3} size={100} color="#0a0a0b">
          SIN RESPUESTA
        </Reveal>
        <div style={{ height: 42 }} />
        <Reveal at={7} size={73} color="#0a0a0b">
          PUEDE TERMINAR EN
        </Reveal>
        <Reveal at={11} size={132} color={RED}>
          OTRA COMPRA.
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          top: 0,
          bottom: 0,
          width: 190,
          left: 0,
          background: RED,
          rotate: "-12deg",
          translate: `${interpolate(f, [50, 60], [-380, 1500], clamp)}px 0`,
        }}
      />
    </Stage>
  );
};
