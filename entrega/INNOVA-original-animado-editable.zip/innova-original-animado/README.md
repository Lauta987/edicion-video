# Video original de INNOVA animado

Se conserva el video adjunto, sus seis escenas, sus textos, su orden y su audio. Las imágenes de cada escena se extrajeron del video recibido y se animan por franjas en Remotion: entrada de títulos, globos y elementos gráficos. El archivo fuente tiene 576 × 1024 y el resultado se exporta a 1080 × 1920; la ampliación no añade detalle original. Duración: 17,3 segundos, 30 FPS.

Para editar: `npm ci` y `npm run dev -- --no-open`. Para exportar: `npm run render`. En el entorno de nube: `npm run render -- --browser-executable=/usr/bin/chromium`.

`src/video.tsx` contiene las animaciones y tiempos, `public/escenas` las imágenes extraídas y `public/video-original.mp4` el original con el audio.
