import { useCurrentFrame } from "remotion";
import { Stage, Reveal, RED, title, Icon, enter } from "../design";
import { Laptop } from "../Devices";
const Feature = ({
  label,
  kind,
  at,
  y,
}: {
  label: string;
  kind: string;
  at: number;
  y: number;
}) => {
  const f = useCurrentFrame();
  return (
    <div
      style={{
        position: "absolute",
        top: y,
        left: 100,
        width: 790,
        height: 75,
        display: "flex",
        gap: 20,
        alignItems: "center",
        padding: "0 24px",
        borderRadius: 22,
        background: "#1a1a1c",
        border: "1px solid #303034",
        opacity: enter(f, at, 7),
        translate: `0 ${(1 - enter(f, at)) * 35}px`,
      }}
    >
      <Icon kind={kind} size={35} />
      <span style={{ ...title, fontSize: 43 }}>{label}</span>
    </div>
  );
};
export const Solution = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <div style={{ position: "absolute", left: 84, top: 260, width: 890 }}>
        <Reveal size={105}>TU WEB MUESTRA</Reveal>
        <Reveal at={8} size={84} color={RED}>
          LO QUE TU CLIENTE
          <br />
          NECESITA SABER.
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 600,
          width: 920,
          height: 620,
          scale: 0.99,
          translate: `0 ${(1 - enter(f, 0, 18)) * 50}px`,
          opacity: enter(f, 0, 8),
        }}
      >
        <Laptop angle={0} tilt={0} settled />
      </div>
      <Feature label="PRODUCTOS Y PRECIOS" kind="box" at={18} y={1210} />
      <Feature label="FORMAS DE PAGO" kind="card" at={37} y={1300} />
      <Feature label="ENVÍOS" kind="truck" at={56} y={1390} />
      <Feature label="CONTACTO DIRECTO" kind="chat" at={75} y={1480} />
    </Stage>
  );
};
