import {
  interpolate,
  useCurrentFrame,
  Img,
  staticFile,
  Freeze,
} from "remotion";
import {
  Stage,
  Reveal,
  RED,
  title,
  Arrow,
  enter,
  clamp,
  ease,
} from "../design";
import { Laptop } from "../Devices";
const ClosingInner = () => {
  const frame = useCurrentFrame();
  const f = Math.min(frame, 78);
  return (
    <Stage glow={0.85} still={frame >= 78}>
      <div
        style={{
          position: "absolute",
          left: 425,
          top: 225,
          width: 220,
          height: 220,
          opacity: enter(f, 4, 17),
          translate: `0 ${interpolate(f, [4, 21], [12, 0], { ...clamp, easing: ease })}px`,
          filter: `blur(${interpolate(f, [4, 16], [3, 0], clamp)}px)`,
        }}
      >
        <Img
          src={staticFile("brand/innova.png")}
          style={{ width: "100%", height: "100%", objectFit: "contain" }}
        />
      </div>
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 505,
          width: 920,
          height: 650,
          scale: interpolate(f, [0, 30], [1.025, 1], {
            ...clamp,
            easing: ease,
          }),
        }}
      >
        <Laptop angle={0} tilt={0} settled />
      </div>
      <div style={{ position: "absolute", left: 84, top: 1170, width: 870 }}>
        <Reveal at={7} size={75}>
          TU WEB RESPONDE LO BÁSICO.
        </Reveal>
        <Reveal at={17} size={64} color={RED}>
          VOS ATENDÉS CONSULTAS REALES.
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: 84,
          top: 1360,
          fontSize: 31,
          letterSpacing: 1.8,
          opacity: enter(f, 30, 10),
          translate: `0 ${(1 - enter(f, 30, 10)) * 15}px`,
        }}
      >
        INNOVA — SOLUCIONES DIGITALES
      </div>
      <div
        style={{
          position: "absolute",
          left: 84,
          top: 1470,
          width: 840,
          height: 110,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 25,
          borderRadius: 19,
          background: "linear-gradient(110deg,#ff3156,#f51d45)",
          border: "1px solid #ff6682",
          boxShadow:
            "0 18px 45px #0006,0 4px 32px #ff234b15,inset 0 1px 0 #ffa7b340",
          opacity: enter(f, 37, 7),
          translate: `0 ${(1 - enter(f, 37, 15)) * 38}px`,
          scale: interpolate(
            f,
            [37, 49, 59, 67],
            [0.97, 1.008, 0.999, 1],
            clamp,
          ),
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: -50,
            bottom: -50,
            width: 180,
            background:
              "linear-gradient(90deg,transparent,#ffffff18,transparent)",
            rotate: "-20deg",
            translate: `${interpolate(f, [44, 65], [-600, 700], clamp)}px 0`,
            opacity: interpolate(f, [43, 49, 63, 67], [0, 1, 1, 0], clamp),
          }}
        />
        <span style={{ ...title, fontSize: 48 }}>
          ESCRIBINOS “WEB” POR WHATSAPP
        </span>
        <Arrow size={38} />
      </div>
    </Stage>
  );
};

export const Closing = () => {
  const f = useCurrentFrame();
  return f >= 78 ? (
    <Freeze frame={78}>
      <ClosingInner />
    </Freeze>
  ) : (
    <ClosingInner />
  );
};
