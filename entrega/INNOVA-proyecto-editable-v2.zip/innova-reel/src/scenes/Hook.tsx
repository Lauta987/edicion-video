import { interpolate, useCurrentFrame } from "remotion";
import {
  Stage,
  Reveal,
  RED,
  Notification,
  enter,
  clamp,
  ease,
} from "../design";
import { Phone } from "../Devices";
export const Hook = () => {
  const f = useCurrentFrame();
  const exit = enter(f, 63, 12);
  return (
    <Stage glow={1.25}>
      <div
        style={{
          position: "absolute",
          left: 84,
          top: 255,
          width: 890,
          zIndex: 3,
          translate: `0 ${-exit * 55}px`,
          opacity: 1 - exit,
          filter: `blur(${exit * 4}px)`,
        }}
      >
        <Reveal at={-3} size={105}>
          ¿CUÁNTO DINERO
        </Reveal>
        <Reveal at={5} size={144}>
          PODÉS <span style={{ color: RED }}>PERDER</span>
        </Reveal>
        <Reveal at={12} size={94}>
          POR TARDAR EN
          <br />
          RESPONDER?
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          width: 470,
          height: 880,
          left: 335,
          top: 790,
          translate: `${interpolate(f, [0, 26], [45, 0], { ...clamp, easing: ease })}px ${interpolate(f, [0, 28], [470, 0], { ...clamp, easing: ease })}px`,
          scale: interpolate(f, [0, 32, 75], [0.75, 0.91, 0.94], clamp),
          rotate: `${interpolate(f, [0, 30, 75], [8, 1, 0], { ...clamp, easing: ease })}deg`,
          filter: `blur(${interpolate(f, [0, 12], [3, 0], clamp)}px)`,
        }}
      >
        <Phone
          rotation={interpolate(f, [0, 35, 75], [-28, -15, -12], clamp)}
          tilt={5}
        />
      </div>
      <div style={{ translate: `0 ${Math.sin(f / 22) * 3}px` }}>
        <Notification
          text="Hola, ¿cuánto sale?"
          at={17}
          x={100}
          y={1010}
          width={720}
          small
        />
      </div>
      <div style={{ translate: `0 ${Math.sin(f / 25 + 1) * 3}px` }}>
        <Notification
          text="¿Hacés envíos?"
          at={32}
          x={260}
          y={1200}
          width={640}
          small
        />
      </div>
    </Stage>
  );
};
