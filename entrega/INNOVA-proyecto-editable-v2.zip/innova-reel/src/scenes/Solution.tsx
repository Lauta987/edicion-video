import { interpolate, useCurrentFrame, useVideoConfig, spring } from "remotion";
import {
  Stage,
  Reveal,
  RED,
  title,
  Icon,
  Arrow,
  enter,
  clamp,
  ease,
} from "../design";
import { Laptop } from "../Devices";
const Feature = ({
  label,
  kind,
  at,
  y,
}: {
  label: string;
  kind: string;
  at: number;
  y: number;
}) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({
    frame: f - at,
    fps,
    config: { damping: 17, stiffness: 230 },
  });
  const anim = enter(f, at, 16);
  const ring = Math.sin(anim * Math.PI);
  return (
    <div
      style={{
        position: "absolute",
        top: y,
        left: 100,
        width: 790,
        height: 76,
        display: "flex",
        gap: 22,
        alignItems: "center",
        opacity: enter(f, at, 6),
        translate: `0 ${(1 - p) * 35}px`,
        filter: `blur(${interpolate(f, [at, at + 7], [3, 0], clamp)}px)`,
        borderBottom: "1px solid #ffffff12",
      }}
    >
      <div
        style={{
          position: "relative",
          width: 39,
          height: 39,
          rotate:
            kind === "box"
              ? `${(1 - p) * -35}deg`
              : kind === "card"
                ? `${Math.sin(anim * Math.PI * 2) * 5}deg`
                : "0deg",
          translate:
            kind === "truck"
              ? `${Math.sin(anim * Math.PI * 2) * 8}px 0`
              : kind === "chat"
                ? `0 ${Math.sin(anim * Math.PI * 2) * -5}px`
                : "0 0",
        }}
      >
        <Icon kind={kind} size={38} />
        <div
          style={{
            position: "absolute",
            inset: -8,
            borderRadius: 14,
            border: `1px solid ${RED}`,
            opacity: ring * 0.35,
            scale: 1 + anim * 0.2,
          }}
        />
      </div>
      <span style={{ ...title, fontSize: 46 }}>{label}</span>
      <span
        style={{
          marginLeft: "auto",
          color: RED,
          translate: `${(1 - p) * -12}px ${(1 - p) * 12}px`,
        }}
      >
        <Arrow size={25} />
      </span>
    </div>
  );
};
export const Solution = () => {
  const f = useCurrentFrame();
  return (
    <Stage glow={0.85}>
      <div
        style={{
          position: "absolute",
          left: 84,
          top: 250,
          width: 890,
          translate: `${-enter(f, 109, 11) * 20}px 0`,
          opacity: 1 - enter(f, 109, 11),
        }}
      >
        <Reveal at={3} size={105}>
          TU WEB MUESTRA
        </Reveal>
        <Reveal at={10} size={84} color={RED}>
          LO QUE TU CLIENTE
          <br />
          NECESITA SABER.
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 605,
          width: 920,
          height: 650,
          scale: interpolate(f, [0, 17, 105, 120], [1, 0.985, 1.025, 1.025], {
            ...clamp,
            easing: ease,
          }),
          translate: `0 ${interpolate(f, [0, 12, 24, 100, 120], [0, 10, 0, 0, -100], { ...clamp, easing: ease })}px`,
          rotate: `${interpolate(f, [0, 18], [0.9, 0], { ...clamp, easing: ease })}deg`,
        }}
      >
        <Laptop
          angle={interpolate(f, [0, 22, 120], [0, -6, 0], clamp)}
          tilt={interpolate(f, [0, 13, 25], [0, 4, 0], clamp)}
        />
      </div>
      <Feature label="PRODUCTOS Y PRECIOS" kind="box" at={18} y={1220} />
      <Feature label="FORMAS DE PAGO" kind="card" at={37} y={1310} />
      <Feature label="ENVÍOS" kind="truck" at={56} y={1400} />
      <Feature label="CONTACTO DIRECTO" kind="chat" at={75} y={1490} />
      <div
        style={{
          position: "absolute",
          left: 75,
          top: 1210,
          width: 840,
          height: 380,
          background: "linear-gradient(transparent,#080809)",
          opacity: enter(f, 109, 11),
        }}
      />
    </Stage>
  );
};
