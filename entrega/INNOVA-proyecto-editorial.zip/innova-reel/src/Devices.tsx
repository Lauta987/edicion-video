import React from "react";
import { Img, staticFile, useCurrentFrame, interpolate } from "remotion";
import { BG, RED, title, clamp, enter } from "./design";

export const Phone: React.FC<{
  rotation?: number;
  tilt?: number;
  dim?: number;
  dots?: boolean;
}> = ({ rotation = -18, tilt = 7, dim = 0, dots = false }) => (
  <div style={{ width: 470, height: 880, perspective: 1600 }}>
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        transform: `rotateY(${rotation}deg) rotateX(${tilt}deg) rotateZ(-5deg)`,
        transformStyle: "preserve-3d",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: 72,
          background: "#454548",
          transform: "translateZ(-22px)",
          boxShadow: "30px 45px 90px #0009",
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: 72,
          background:
            "linear-gradient(120deg,#95959a,#29292d 18%,#09090b 50%,#6c6c70)",
          padding: 9,
          boxShadow: "inset 0 0 0 2px #a1a1a155",
        }}
      >
        <div
          style={{
            position: "relative",
            height: "100%",
            overflow: "hidden",
            borderRadius: 63,
            border: "7px solid #050506",
            background: "linear-gradient(165deg,#29292e,#111114 65%)",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "32px 30px 0",
              fontSize: 21,
              color: "#d9d9de",
            }}
          >
            <span>9:41</span>
            <span>▮▮▮ ▰</span>
          </div>
          <div
            style={{
              position: "absolute",
              top: 20,
              left: 151,
              width: 145,
              height: 37,
              borderRadius: 24,
              background: "#030304",
            }}
          />
          <div style={{ padding: "90px 28px 25px" }}>
            <div
              style={{
                width: 50,
                height: 50,
                borderRadius: 16,
                background: RED,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 30,
                color: "white",
              }}
            >
              ···
            </div>
            <div style={{ ...title, fontSize: 55, marginTop: 22 }}>
              CONSULTAS
            </div>
            <div
              style={{ height: 1, background: "#ffffff1a", marginTop: 28 }}
            />
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  gap: 18,
                  marginTop: 27,
                  opacity: 0.35,
                }}
              >
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 40,
                    background: "#666",
                  }}
                />
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      width: "70%",
                      height: 8,
                      borderRadius: 4,
                      background: "#999",
                      margin: "8px 0 12px",
                    }}
                  />
                  <div
                    style={{
                      width: "90%",
                      height: 7,
                      borderRadius: 4,
                      background: "#666",
                    }}
                  />
                </div>
              </div>
            ))}
            {dots && (
              <div
                style={{
                  marginTop: 60,
                  borderRadius: 24,
                  background: "#333338",
                  width: 130,
                  height: 68,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 10,
                }}
              >
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    style={{
                      width: 12,
                      height: 12,
                      borderRadius: 20,
                      background: "#bdbdc3",
                    }}
                  />
                ))}
              </div>
            )}
          </div>
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: `rgba(0,0,0,${dim})`,
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              background:
                "linear-gradient(120deg,#fff1,transparent 40%,transparent 80%,#fff08)",
              pointerEvents: "none",
            }}
          />
          <div
            style={{
              position: "absolute",
              bottom: 18,
              left: 137,
              width: 170,
              height: 5,
              borderRadius: 10,
              background: "#ccc9",
            }}
          />
        </div>
      </div>
    </div>
  </div>
);

export const Shop = ({
  preview = true,
  settled = false,
}: {
  preview?: boolean;
  settled?: boolean;
}) => {
  const frame = useCurrentFrame();
  const f = settled ? 100 : frame;
  const feature = f < 37 ? 0 : f < 56 ? 1 : f < 75 ? 2 : 3;
  const active = preview && f >= 18;
  const x = interpolate(
    f,
    [18, 33, 37, 52, 56, 71, 75, 92],
    [370, 370, 200, 200, 500, 500, 742, 742],
    clamp,
  );
  const y = interpolate(
    f,
    [18, 33, 37, 52, 56, 71, 75, 92],
    [330, 330, 442, 442, 442, 442, 53, 53],
    clamp,
  );
  return (
    <div
      style={{
        position: "relative",
        height: "100%",
        background: "#f2f0ec",
        color: "#202020",
        fontFamily: "Open Sans",
        lineHeight: 1.15,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          background: "#151516",
          height: 27,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#ddd",
          fontSize: 10,
          letterSpacing: 2,
        }}
      >
        OBJETOS PARA TU DÍA A DÍA
      </div>
      <div
        style={{
          height: 57,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "0 30px",
          borderBottom: "1px solid #ddd9d5",
        }}
      >
        <b style={{ fontSize: 25, letterSpacing: 5 }}>NIDO.</b>
        <div style={{ display: "flex", gap: 23, fontSize: 12 }}>
          <span style={{ color: active && feature === 0 ? RED : undefined }}>
            Productos
          </span>
          <span style={{ color: active && feature === 1 ? RED : undefined }}>
            Pagos
          </span>
          <span style={{ color: active && feature === 2 ? RED : undefined }}>
            Envíos
          </span>
          <span style={{ color: RED }}>Contacto</span>
        </div>
      </div>
      <div
        style={{
          display: "flex",
          height: 144,
          padding: "20px 30px",
          gap: 30,
          background: "#e8e5e0",
          position: "relative",
        }}
      >
        <div style={{ width: "55%", position: "relative", zIndex: 1 }}>
          <div style={{ fontSize: 11, letterSpacing: 2, color: "#777" }}>
            SIMPLE. ÚTIL. COTIDIANO.
          </div>
          <div
            style={{ ...title, fontSize: 40, lineHeight: 0.97, marginTop: 7 }}
          >
            Tu casa, un lugar
            <br />
            más tuyo.
          </div>
          <div
            style={{
              background: RED,
              color: "white",
              padding: "7px 14px",
              marginTop: 12,
              width: 116,
              fontSize: 11,
              borderRadius: 4,
            }}
          >
            Ver productos
          </div>
        </div>
        <Img
          src={staticFile("products/lamp.svg")}
          style={{
            position: "absolute",
            width: 230,
            height: 210,
            right: 26,
            top: -28,
            translate: `0 ${preview ? Math.sin(Math.min(f, 100) / 35) * -2 : 0}px`,
          }}
        />
      </div>
      <div style={{ padding: "12px 30px", position: "relative" }}>
        <div style={{ fontSize: 14, marginBottom: 9, fontWeight: 600 }}>
          Elegidos para tu espacio
        </div>
        <div style={{ display: "flex", gap: 16 }}>
          <Product src="lamp.svg" name="Lámpara Alba" price="$ 48.000" />
          <Product src="vase.svg" name="Florero Arena" price="$ 22.000" />
          <Product src="cup.svg" name="Taza Origen" price="$ 12.000" />
        </div>
        <div
          style={{
            position: "absolute",
            inset: "28px 19px 4px",
            border: `1.5px solid ${RED}`,
            borderRadius: 8,
            opacity: active && feature === 0 ? 0.6 * enter(f, 18, 8) : 0,
            pointerEvents: "none",
          }}
        />
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          padding: "8px 30px",
          fontSize: 11,
          borderTop: "1px solid #ddd",
          position: "relative",
        }}
      >
        <span style={{ color: active && feature === 1 ? RED : undefined }}>
          Transferencia · Tarjetas
        </span>
        <span style={{ color: active && feature === 2 ? RED : undefined }}>
          Envíos a todo el país
        </span>
        <span style={{ color: RED }}>Hablemos</span>
      </div>
      {preview && (
        <div
          style={{
            position: "absolute",
            left: x,
            top: y,
            opacity: enter(f, 20, 8),
            pointerEvents: "none",
            filter: "drop-shadow(0 2px 2px #0004)",
          }}
        >
          <svg width="18" height="23" viewBox="0 0 18 23">
            <path
              d="M1 1v19l5-5 4 7 4-2-4-7 7-1z"
              fill="#151516"
              stroke="white"
              strokeWidth="1.2"
            />
          </svg>
        </div>
      )}
    </div>
  );
};
const Product = ({
  src,
  name,
  price,
}: {
  src: string;
  name: string;
  price: string;
}) => (
  <div style={{ flex: 1, minWidth: 0 }}>
    <div style={{ background: "#e5e1dc", height: 104, borderRadius: 5 }}>
      <Img
        src={staticFile(`products/${src}`)}
        style={{ height: "100%", width: "100%", objectFit: "contain" }}
      />
    </div>
    <div style={{ fontSize: 12, marginTop: 6 }}>{name}</div>
    <div style={{ fontSize: 13, marginTop: 3, fontWeight: 700 }}>{price}</div>
  </div>
);

const LaptopBody = ({ settled = false }: { settled?: boolean }) => (
  <div style={{ position: "relative", width: 920, height: 574 }}>
    <div
      style={{
        width: 840,
        height: 540,
        margin: "0 auto",
        borderRadius: "26px 26px 9px 9px",
        padding: "24px 15px 20px",
        background:
          "linear-gradient(140deg,#818189,#29292d 20%,#111114 70%,#62626a)",
        boxShadow: "0 28px 62px #0007",
        border: "2px solid #75757b",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 10,
          left: 456,
          width: 5,
          height: 5,
          background: "#080809",
          borderRadius: 8,
        }}
      />
      <div
        style={{
          height: "100%",
          overflow: "hidden",
          borderRadius: 5,
          border: "2px solid #050505",
          position: "relative",
        }}
      >
        <div
          style={{
            background: "#ddd",
            height: 23,
            display: "flex",
            alignItems: "center",
            padding: "0 10px",
            gap: 5,
          }}
        >
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                width: 5,
                height: 5,
                borderRadius: 5,
                background: "#999",
              }}
            />
          ))}
          <span style={{ fontSize: 8, color: "#777", marginLeft: 180 }}>
            nido.tienda · Sitio de demostración
          </span>
        </div>
        <div style={{ height: 467 }}>
          <Shop settled={settled} />
        </div>
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "linear-gradient(115deg,#ffffff0c,transparent 45%,transparent 78%,#ffffff04)",
            pointerEvents: "none",
          }}
        />
      </div>
    </div>
    <div
      style={{
        position: "absolute",
        left: 0,
        top: 537,
        height: 29,
        width: 920,
        borderRadius: "2px 2px 43px 43px",
        background: "linear-gradient(#b5b5bc,#66666e 30%,#28282c 75%,#161619)",
        borderTop: "1.5px solid #d4d4db",
        boxShadow: "0 15px 27px #0006",
      }}
    >
      <div
        style={{
          height: 8,
          width: 140,
          margin: "0 auto",
          background: "#45454a",
          borderRadius: "0 0 14px 14px",
          boxShadow: "inset 0 1px 2px #0006",
        }}
      />
    </div>
  </div>
);
export const Laptop = ({
  angle = -7,
  tilt = 3,
  settled = false,
}: {
  angle?: number;
  tilt?: number;
  settled?: boolean;
}) => (
  <div
    style={{ width: 920, height: 650, perspective: 1800, position: "relative" }}
  >
    <div
      style={{
        position: "absolute",
        left: 70,
        top: 540,
        width: 780,
        height: 120,
        borderRadius: "50%",
        background: "radial-gradient(ellipse,#000b,transparent 70%)",
        filter: "blur(19px)",
      }}
    />
    <div
      style={{
        position: "relative",
        width: "100%",
        transform: `rotateY(${angle}deg) rotateX(${tilt}deg)`,
        transformStyle: "preserve-3d",
      }}
    >
      <LaptopBody settled={settled} />
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 566,
          width: 920,
          height: 95,
          overflow: "hidden",
          opacity: 0.075,
          filter: "blur(1.4px)",
          maskImage: "linear-gradient(#000,transparent 92%)",
          WebkitMaskImage: "linear-gradient(#000,transparent 92%)",
        }}
      >
        <div style={{ height: 574, transform: "scaleY(-1)" }}>
          <LaptopBody settled={settled} />
        </div>
      </div>
    </div>
  </div>
);

export const Bubble: React.FC<{
  text: string;
  style?: React.CSSProperties;
}> = ({ text, style }) => (
  <div
    style={{
      display: "flex",
      alignItems: "center",
      gap: 22,
      padding: "26px 30px",
      borderRadius: "25px 25px 25px 7px",
      background: "linear-gradient(125deg,#f7f6f4,#dfdddd)",
      color: BG,
      border: "1px solid #ffffffb0",
      boxShadow: "0 22px 55px #0007,inset 0 1px 0 #fff",
      fontSize: 44,
      lineHeight: 1.2,
      ...style,
    }}
  >
    <div
      style={{
        width: 34,
        height: 34,
        borderRadius: 11,
        border: "1px solid #08080920",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
    >
      <div style={{ width: 7, height: 7, borderRadius: 8, background: RED }} />
    </div>
    <span>{text}</span>
  </div>
);
