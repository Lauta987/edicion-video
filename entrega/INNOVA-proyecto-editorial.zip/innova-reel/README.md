# INNOVA — Reel editorial

Edición basada en el reel anterior y la referencia visual adjunta. Conserva las cinco escenas, sus textos y el CTA. Duración: 16 segundos, 1080 × 1920, 30 FPS.

Para editar: `npm ci` y `npm run dev -- --no-open`. Para exportar: `npm run render` (requiere FFmpeg y ffprobe). En este entorno: `npm run render -- --browser-executable=/usr/bin/chromium`. La salida es `out/INNOVA-Reel-editorial.mp4`.

Las escenas están en `src/scenes/`, los recursos en `public/` y la música y efectos originales en `public/audio/`. El logo es el recurso sin fondo usado en la versión anterior.
