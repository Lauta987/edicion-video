import { useCurrentFrame, interpolate } from "remotion";
import { Stage, Reveal, RED, title, enter, clamp } from "../design";
const Msg = ({
  text,
  at,
  y,
  red = false,
  time,
}: {
  text: string;
  at: number;
  y: number;
  red?: boolean;
  time: string;
}) => {
  const f = useCurrentFrame();
  return (
    <div
      style={{
        position: "absolute",
        left: 100,
        top: y,
        width: 830,
        display: "flex",
        alignItems: "end",
        gap: 14,
        opacity: enter(f, at, 5),
        translate: `0 ${(1 - enter(f, at, 12)) * 55}px`,
        scale: interpolate(f, [at, at + 9, at + 15], [0.96, 1.01, 1], clamp),
        transformOrigin: "left center",
      }}
    >
      <div
        className="speech"
        style={{
          background: red ? RED : "#f8f8f8",
          color: red ? "white" : "#101011",
          padding: "23px 30px",
          borderRadius: "34px 34px 34px 5px",
          fontSize: 43,
          fontWeight: 700,
          lineHeight: 1.18,
        }}
      >
        {text}
      </div>
      <span style={{ fontSize: 22, color: "#777", paddingBottom: 8 }}>
        {time}
      </span>
    </div>
  );
};
export const Problem = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <div style={{ position: "absolute", left: 84, top: 255 }}>
        <Reveal size={88}>LAS MISMAS PREGUNTAS.</Reveal>
        <Reveal size={68} color={RED} at={5}>
          UNA Y OTRA VEZ.
        </Reveal>
      </div>
      <Msg text="Hola, ¿cuánto sale?" at={0} y={630} time="10:01" />
      <Msg text="¿Hacés envíos?" at={12} y={790} time="10:02" />
      <Msg text="¿Qué medios de pago aceptás?" at={25} y={950} time="10:03" />
      <Msg text="¿Todavía tenés stock?" at={44} y={1110} red time="10:04" />
      <div
        style={{
          position: "absolute",
          left: 100,
          top: 1450,
          background: RED,
          color: "white",
          padding: "22px 30px",
          borderRadius: "28px 28px 28px 5px",
          ...title,
          fontSize: 46,
          opacity: enter(f, 58),
          translate: `0 ${(1 - enter(f, 58)) * 30}px`,
        }}
      >
        RESPONDER TODO A MANO
      </div>
    </Stage>
  );
};
