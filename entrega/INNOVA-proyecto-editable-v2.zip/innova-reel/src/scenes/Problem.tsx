import { interpolate, useCurrentFrame, useVideoConfig, spring } from "remotion";
import { Stage, Reveal, RED, title, enter, clamp, ease } from "../design";
import { Phone, Bubble } from "../Devices";
export const Message = ({
  text,
  index,
  at,
  compress = 0,
}: {
  text: string;
  index: number;
  at: number;
  compress?: number;
}) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({
    frame: f - at,
    fps,
    config: { damping: 14, stiffness: 230, mass: 0.7 },
  });
  const nudge = [4, 20, 39, 57]
    .slice(index + 1)
    .reduce((sum, n) => sum + enter(f, n, 10) * 24, 0);
  const y = 700 + index * 155 - nudge;
  const base = index === 0 ? 1010 : 1200;
  const fromHook = index < 2;
  const actualY = fromHook
    ? interpolate(f, [0, 23], [base, y], { ...clamp, easing: ease })
    : y;
  return (
    <div
      style={{
        position: "absolute",
        left: fromHook
          ? interpolate(f, [0, 23], [index === 0 ? 100 : 260, 100], {
              ...clamp,
              easing: ease,
            })
          : 100,
        top: actualY,
        width: fromHook
          ? interpolate(f, [0, 23], [index === 0 ? 720 : 640, 790], {
              ...clamp,
              easing: ease,
            })
          : 790,
        opacity: (fromHook ? 1 : enter(f, at, 5)) * (1 - compress),
        translate: `${compress * 220}px ${(1 - p) * 65 + compress * (900 - actualY)}px`,
        scale: (fromHook ? 1 : 0.95 + p * 0.05) * (1 - compress * 0.6),
        rotate: `${Math.sin((f - at) * 1.4) * Math.max(0, 1 - (f - at) / 8) * 0.25}deg`,
        filter: `blur(${(fromHook ? 0 : interpolate(f, [at, at + 7], [4, 0], clamp)) + compress * 6}px)`,
      }}
    >
      <Bubble
        text={text}
        style={{
          fontSize: fromHook ? interpolate(f, [0, 23], [40, 44], clamp) : 44,
        }}
      />
    </div>
  );
};
export const Problem = () => {
  const f = useCurrentFrame();
  const squeeze = enter(f, 82, 8);
  return (
    <Stage glow={1.15}>
      <div
        style={{
          position: "absolute",
          left: 84,
          top: 250,
          opacity: 1 - squeeze,
          translate: `0 ${-squeeze * 25}px`,
        }}
      >
        <Reveal size={88} at={1}>
          LAS MISMAS PREGUNTAS.
        </Reveal>
        <Reveal size={68} color={RED} at={7}>
          UNA Y OTRA VEZ.
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: interpolate(f, [0, 23], [335, 300], { ...clamp, easing: ease }),
          top: interpolate(f, [0, 23], [790, 500], { ...clamp, easing: ease }),
          width: 470,
          height: 880,
          scale: interpolate(f, [0, 23, 90], [0.94, 1.12, 1.19], clamp),
        }}
      >
        <Phone
          rotation={interpolate(f, [0, 25, 90], [-12, -9, -4], clamp)}
          tilt={5}
        />
      </div>
      <Message text="Hola, ¿cuánto sale?" index={0} at={0} compress={squeeze} />
      <Message text="¿Hacés envíos?" index={1} at={4} compress={squeeze} />
      <Message
        text="¿Qué medios de pago aceptás?"
        index={2}
        at={23}
        compress={squeeze}
      />
      <Message
        text="¿Todavía tenés stock?"
        index={3}
        at={44}
        compress={squeeze}
      />
      <div
        style={{
          position: "absolute",
          left: 100,
          top: 1460,
          padding: "21px 29px",
          background: RED,
          border: "1px solid #ff6e89",
          borderRadius: 15,
          boxShadow: "0 14px 40px #0005",
          opacity: enter(f, 59, 7) * (1 - squeeze),
          translate: `0 ${(1 - enter(f, 59)) * 30}px`,
          scale: interpolate(
            f,
            [59, 67, 73, 80],
            [0.94, 1.015, 0.988, 1],
            clamp,
          ),
          ...title,
          fontSize: 45,
        }}
      >
        RESPONDER TODO A MANO
      </div>
    </Stage>
  );
};
