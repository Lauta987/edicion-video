"""Original 120 BPM instrumental + synchronized interface sound design. No samples."""
from pathlib import Path
import wave
import numpy as np
SR=48000
D=16
rng=np.random.default_rng(20261027)
N=SR*D
music=np.zeros((N,2),np.float64)
fx=np.zeros((N,2),np.float64)
def place(target,t,sound,gain=1,pan=0):
    i=round(t*SR)
    n=min(len(sound),N-i)
    if n<=0:return
    target[i:i+n,0]+=sound[:n]*gain*np.sqrt((1-pan)/2)
    target[i:i+n,1]+=sound[:n]*gain*np.sqrt((1+pan)/2)
def time(d):return np.arange(round(d*SR))/SR
# Sub kick, tight snare, filtered hats.
for b in np.arange(0,16,.5):
    t=time(.32)
    kick=np.sin(2*np.pi*(45*t+80*.035*(1-np.exp(-t/.035))))*np.exp(-t*17)
    gain=.40 if not 5.5<=b<7.5 else .17
    place(music,b,kick,gain)
    if int(b*2)%2==1:
        t=time(.13);noise=rng.normal(0,1,len(t));noise=np.r_[0,np.diff(noise)]*.22
        snare=(noise+np.sin(2*np.pi*185*t)*.2)*np.exp(-t*32)
        place(music,b,snare,.23)
for b in np.arange(.25,15.8,.25):
    t=time(.055);n=rng.normal(0,1,len(t));n=np.r_[0,np.diff(n)]
    place(music,b,n*np.exp(-t*95),.018 if b%.5 else .026,(-1 if int(b*4)%2 else 1)*.4)
# C minor bass and syncopated, soft metallic arpeggio.
notes=[130.8128,155.5635,195.9977,233.0819,195.9977,155.5635,261.6256,195.9977]
for i,b in enumerate(np.arange(0,16,.25)):
    t=time(.42);f=notes[i%8]
    env=(1-np.exp(-t*190))*np.exp(-t*11)
    sig=(np.sin(2*np.pi*f*2*t)+.24*np.sin(2*np.pi*f*4.002*t)+.1*np.sin(2*np.pi*f*6*t))*env
    place(music,b,sig,.068 if not 5.5<=b<7.5 else .025, np.sin(i*.8)*.45)
    place(music,b+.13,sig,.019,-np.sin(i*.8)*.5)
for b in np.arange(0,16,.5):
    t=time(.36);f=65.4064 if b<7.5 else 51.9131
    bass=(np.sin(2*np.pi*f*t)+.16*np.sin(2*np.pi*f*2*t))*(1-np.exp(-t*80))*np.exp(-t*8)
    place(music,b+.065,bass,.22)
# Notification double chirps match message appearance, not a real app sound.
for event in [17/30,32/30,2.5+23/30,2.5+44/30]:
    for delay,freq,amp in [(0,1050,.15),(.075,1530,.12)]:
        t=time(.13);env=(1-np.exp(-t*500))*np.exp(-t*32)
        place(fx,event+delay,(np.sin(2*np.pi*freq*t)+.2*np.sin(2*np.pi*freq*2*t))*env,amp,.15)
# Soft title impacts.
for event in [0,5/30,12/30,2.5,2.5+7/30,5.5,5.5+8/30,7.5+3/30,7.5+10/30,11.5+7/30,11.5+17/30,11.5+37/30]:
    t=time(.22);impact=np.sin(2*np.pi*(64*t+35*.025*(1-np.exp(-t/.025))))*np.exp(-t*25)
    place(fx,event,impact,.23)
# Stereo sweeps across the scene boundaries.
for event in [2.35,5.22,6.85,11.25]:
    t=time(.27);noise=rng.normal(0,1,len(t));noise=np.convolve(noise,np.ones(12)/12,mode='same')
    env=np.sin(np.pi*np.clip(t/.27,0,1))**2
    place(fx,event,noise*env,.18,-.4)
    place(fx,event+.035,noise*env,.13,.5)
# Ending resolves, with a short tail and clean fade.
t=time(1.2)
chord=sum(np.sin(2*np.pi*f*t) for f in [130.8128,155.5635,195.9977])/3
place(music,14.75,chord*np.exp(-t*4),.12)
fade=np.minimum(np.arange(N)/(.015*SR),1)*np.minimum(np.arange(N)[::-1]/(.35*SR),1)
def save(name,data):
    data=np.clip(data*fade[:,None],-.98,.98)
    with wave.open(str(Path(__file__).resolve().parents[1]/'public/audio'/name),'wb') as w:
        w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((data*32767).astype('<i2').tobytes())
save('music-original.wav',music)
save('sound-design.wav',fx)
save('pre-master.wav',music+fx)
